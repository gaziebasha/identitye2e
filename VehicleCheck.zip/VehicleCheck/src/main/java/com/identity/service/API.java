package com.identity.service;


import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;

public class API {

    public Response postResponse(final String uri, final String body, final Object... pathReplacementParams) {


        return RestAssured.given()
                .header("Accept", "application/json")
                .contentType("application/json")
                .body(body)
                .when()
                .request(Method.POST, uri)
                .then()
                .log().all()
                .extract()
                .response();
    }
}
