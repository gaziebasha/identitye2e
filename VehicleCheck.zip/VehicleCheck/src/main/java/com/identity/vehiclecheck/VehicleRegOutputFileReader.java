package com.identity.vehiclecheck;


import com.identity.test.VehicleDetails;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class VehicleRegOutputFileReader {

    public List<VehicleDetails> getVehicleDetails(final String outputFilePath) throws IOException, ClassNotFoundException {
        List<VehicleDetails> expectedVehicleDetails = new ArrayList<>();
        FileInputStream outputFileInStream = new FileInputStream(outputFilePath);
        ObjectInputStream VehicleObjectStream = new ObjectInputStream(outputFileInStream);
        VehicleDetails vehicleDetailsObject = (VehicleDetails)VehicleObjectStream.readObject();
        while(vehicleDetailsObject!=null){
            expectedVehicleDetails.add(vehicleDetailsObject);
            vehicleDetailsObject = (VehicleDetails)VehicleObjectStream.readObject();
        }
        VehicleObjectStream.close();
        return expectedVehicleDetails;
    }

}
