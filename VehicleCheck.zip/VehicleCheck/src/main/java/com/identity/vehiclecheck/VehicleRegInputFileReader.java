package com.identity.vehiclecheck;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VehicleRegInputFileReader {

    public static final String VEHICLE_REG_NUMBER_PATTERN = "[A-Z]{2}[0-9]{2}\\s?[A-Z]{3}?";

    public List<File> getVehicleInputFiles(String vehicleInputFilesLocation) {
        File inputDirectory = new File(vehicleInputFilesLocation);

        List<File> inFilesList = new ArrayList<>();

        File[] inputFileObjects = inputDirectory.listFiles();
        inFilesList.addAll(Arrays.asList(inputFileObjects));
        for (File file : inputFileObjects) {
            if (file.isFile()) {
            } else if (file.isDirectory()) {
                inFilesList.addAll(getVehicleInputFiles(file.getAbsolutePath()));
            }
        }
        return inFilesList;
    }

    public List<String> getVehicleRegistrationNumbers(String vehicleInputFilesLocation) throws IOException {
        List<String> matches = new ArrayList<>();
        List<File> files = getVehicleInputFiles(vehicleInputFilesLocation);
        for (File file: files) {
            BufferedReader fileBuffReader = new BufferedReader(new FileReader(file));
            String line;
            while((line=fileBuffReader.readLine())!=null){
                Pattern pattern = Pattern.compile(VEHICLE_REG_NUMBER_PATTERN);
                Matcher matcher = pattern.matcher(line);
                while (matcher.find()) {
                    for (int i = 0; i <= matcher.groupCount(); i++) {
                        matches.add(matcher.group(i));
                    }
                }
            }
            fileBuffReader.close();
        }
        return matches;
    }
}
