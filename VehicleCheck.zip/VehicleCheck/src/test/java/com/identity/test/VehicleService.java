package com.identity.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

public class VehicleService {

    static WebDriver driver;

    public VehicleDetails getVehicleDetails(final String url, final String vRegNum){
        //C:/workspace/VehicleCheck/src/test/resources/geckodriver.exe"
        System.setProperty("webdriver.gecko.driver", "./src/test/resources/geckodriver.exe");
        driver = new FirefoxDriver();
        driver.get(url);
        InputVehicleRegPage inputVehicleRegPage = PageFactory.initElements(driver, InputVehicleRegPage.class);
        VehicleDetailsPage vehicleDetailsPage = PageFactory.initElements(driver, VehicleDetailsPage.class);
        inputVehicleRegPage.enterRegNumber(vRegNum);
        inputVehicleRegPage.clickFreeCarCheck();
        VehicleDetails vehicleDetails = new VehicleDetails();
        vehicleDetails.setRegNumber(vehicleDetailsPage.getRegNumber());
        vehicleDetails.setMake(vehicleDetailsPage.getMake());
        vehicleDetails.setModal(vehicleDetailsPage.getModal());
        vehicleDetails.setColour(vehicleDetailsPage.getColour());
        vehicleDetails.setYear(vehicleDetailsPage.getYear());
        driver.close();
        return vehicleDetails;
    }
}
