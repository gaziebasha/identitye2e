package com.identity.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class VehicleDetailsPage {

        WebDriver driver;

        @FindBy(xpath="/html/body/div/div/div/div[3]/div[1]/div/span/div[2]/dl[1]/dd")
        WebElement regNumber ;

        @FindBy(xpath="/html/body/div/div/div/div[3]/div[1]/div/span/div[2]/dl[2]/dd")
        WebElement make ;

        @FindBy(xpath="/html/body/div/div/div/div[3]/div[1]/div/span/div[2]/dl[3]/dd")
        WebElement modal ;

        @FindBy(xpath="/html/body/div/div/div/div[3]/div[1]/div/span/div[2]/dl[4]/dd")
        WebElement colour ;

        @FindBy(xpath="/html/body/div/div/div/div[3]/div[1]/div/span/div[2]/dl[5]/dd")
        WebElement year ;

        public VehicleDetailsPage(WebDriver driver){
            this.driver = driver;
        }

        public String getRegNumber(){
           return regNumber.getText();
        }

        public String getMake(){
            return make.getText();
        }

        public String getYear(){
            return modal.getText();
        }

        public String getModal(){
            return colour.getText();
        }

        public String getColour(){
            return year.getText();
        }
}
