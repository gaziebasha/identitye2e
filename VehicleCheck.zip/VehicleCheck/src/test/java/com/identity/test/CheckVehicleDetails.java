package com.identity.test;

import com.identity.vehiclecheck.VehicleRegInputFileReader;
import com.identity.vehiclecheck.VehicleRegOutputFileReader;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CheckVehicleDetails {
    List<String> vehicleRegNumbers;
    List<VehicleDetails> actualVehicleDetails = new ArrayList<>();
    List<VehicleDetails> expectedVehicleDetails = new ArrayList<>();

    @Given("^I have vehicle registration numbers from input files located at \"([^\"]*)\"$")
    public void iHaveVehicleRegistrationNumbersFromInputFilesLocatedAt(final String inputFilesDirLocation) throws IOException {
        VehicleRegInputFileReader vehicleInputReader = new VehicleRegInputFileReader();
        vehicleRegNumbers = vehicleInputReader.getVehicleRegistrationNumbers(inputFilesDirLocation);
    }


    @When("^I get vehicle details from online \"([^\"]*)\"$")
    public void iGetVehicleDetailsFrom(String onlineVehicleCheckUrl) {
        VehicleService vehicleService = new VehicleService();
        for (String vRegNum: vehicleRegNumbers){
            actualVehicleDetails.add(vehicleService.getVehicleDetails(onlineVehicleCheckUrl, vRegNum));
        }
    }

    @Then("^below vehicle detail values from online should match with the expected values in the output file located at \"([^\"]*)\"$")
    public void belowVehicleValuesFromOnlineShouldMatchWithTheExpectedValuesInTheOutputFileLocatedAt(String outputFilePath) throws IOException, ClassNotFoundException {
        VehicleRegOutputFileReader vehicleRegOutputFileReader = new VehicleRegOutputFileReader();
        expectedVehicleDetails = vehicleRegOutputFileReader.getVehicleDetails(outputFilePath);
        Assert.assertEquals(expectedVehicleDetails, actualVehicleDetails);
    }
}
