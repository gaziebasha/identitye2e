package com.identity.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class InputVehicleRegPage {

        WebDriver driver;

        @FindBy(id="vrm-input")
        WebElement regNumber;

        @FindBy(how = How.XPATH, using = "/html/body/div/div/div[1]/div/div/div/div/span/form/button")
        WebElement freeCarCheck;

        public InputVehicleRegPage(WebDriver driver){
            this.driver = driver;
        }

        public void enterRegNumber(String registrationNumber){
            regNumber.sendKeys(registrationNumber);
        }

        public void clickFreeCarCheck(){
             freeCarCheck.click();
        }
}
